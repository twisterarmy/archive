var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");



}
/*
     FILE ARCHIVED ON 10:50:08 Feb 08, 2017 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:30:41 Mar 28, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  PetaboxLoader3.resolve: 146.99 (2)
  captures_list: 564.917
  exclusion.robots.policy: 0.181
  CDXLines.iter: 27.711 (3)
  load_resource: 490.333 (2)
  PetaboxLoader3.datanode: 354.911 (5)
  LoadShardBlock: 531.737 (3)
  exclusion.robots: 0.191
  esindex: 0.01
  RedisCDXSource: 0.842
*/