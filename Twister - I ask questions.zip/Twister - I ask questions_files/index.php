var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");



}
/*
     FILE ARCHIVED ON 10:50:08 Feb 08, 2017 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:57:17 Mar 28, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 132.09
  exclusion.robots: 0.119
  exclusion.robots.policy: 0.11
  RedisCDXSource: 1.897
  esindex: 0.011
  LoadShardBlock: 105.027 (3)
  PetaboxLoader3.datanode: 154.288 (5)
  CDXLines.iter: 22.196 (3)
  load_resource: 213.944 (2)
  PetaboxLoader3.resolve: 82.815 (2)
*/