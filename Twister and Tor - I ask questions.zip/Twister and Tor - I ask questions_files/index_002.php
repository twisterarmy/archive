var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");



}
/*
     FILE ARCHIVED ON 17:57:55 Feb 19, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:30:36 Mar 28, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  CDXLines.iter: 29.907 (3)
  captures_list: 193.715
  load_resource: 191.674 (2)
  PetaboxLoader3.resolve: 57.641 (2)
  exclusion.robots.policy: 0.193
  PetaboxLoader3.datanode: 231.976 (5)
  LoadShardBlock: 147.211 (3)
  exclusion.robots: 0.208
  RedisCDXSource: 10.331
  esindex: 0.016
*/